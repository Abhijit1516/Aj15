package com.logical.arrays;

import java.util.Arrays;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class ArrayOperations {

	static int[] raw = new int[10];
	static int rawIndex;
	static int[] testArray = { 8, 7, 5, 4, 6, 6, 7, 2 };

	public static void main(String[] args) {
		// show(testArray);
		/*
		 * //==========1. o/p findDuplicate(ar); show(raw); show(ar);
		 */

		/*
		 * IntStream stream = Arrays.stream(ar);
		 * stream.distinct().forEach(System.out::println);
		 */

		// =============2. o/p

		/*
		 * show(testArray); show(removeDuplicate(testArray));
		 */

		// maxDifference(testArray);

		/*
		 * int sum = sumOfUnique(testArray); System.out.println("Sum is :" + sum);
		 */
		// Arrays.stream(testArray).sorted().forEach(System.out::print);
		// show(sortByOrder(testArray));
		// System.out.println("Nth largest number is " + nThLargestNo(testArray, 2));
		// findMinMax(testArray);
		// find2ndMinMax(testArray);
		/*
		 * int[] a = { 1, 5, 10, 20, 40, 80 }; int[] b = { 6, 7, 20, 80, 100 }; int[] c
		 * = { 3, 4, 15, 20, 30, 70, 80, 120 };
		 * 
		 * commonElementsAmmongArrays(a, b, c);
		 */
		int[] pair = { 3, 6, 8, -8, 10, 8 };
		// findPairs(pair, 16);
		minPair(pair);
	}

//1.===============1.
	public static void findDuplicate(int[] inArray) {
		int maxIndex = inArray.length - 1;
		System.out.println("Duplicates found are : ");
		for (int i = 0; i <= maxIndex; i++) {
			for (int k = i + 1; k < maxIndex + 1; k++) {
				if (inArray[i] == inArray[k] && !isAvailable(inArray[i])) {
					addElement(inArray[i]);
					System.out.print(" " + inArray[i]);
					break;
				}

			}
		}

	}

	/*
	 * search for duplicate if found< remove and shift all elements to left >
	 */
	// 2.=============2.
	public static int[] removeDuplicate(int[] inArray) {
		int maxIndex = inArray.length - 1;
		int[] resultantArray = null;
		for (int i = 0; i <= maxIndex; i++) {
			for (int k = i + 1; k < maxIndex + 1; k++) {
				if (inArray[i] == inArray[k]) {
					removeElement(k);
				}
			}
		}
		resultantArray = testArray;
		return resultantArray;
	}

	// 3.==================3.
	public static int sumOfUnique(int[] inArray) {
		int[] unique = removeDuplicate(inArray);
		System.out.println("Unique Elements Are");
		show(unique);
		int sum = 0;
		for (int i = 0; i < unique.length; i++) {
			sum = sum + unique[i];
		}
		return sum;
	}

	// 4.======================4.
	public static int nThLargestNo(int[] a, int n) {
		int[] b = sortByOrder(removeDuplicate(a));
		if (n < 0) {
			int ix = Math.abs(n);
			return b[ix - 1];
		}
		// show(b);
		// System.out.println(b.length);
		return b[(b.length - n)];
	}

	// 5.=========================5.
	public static void maxDifference(int[] a) {
		int highestNo = nThLargestNo(a, 0);
		int lowestNo = nThLargestNo(a, a.length);
		System.out.println(highestNo + " " + lowestNo);
		System.out.println("highest Difference is : " + (highestNo - lowestNo));
	}

	// 6.==========================6.
	public static void findMinMax(int[] a) {
		int highestNo = nThLargestNo(a, 0);
		int lowestNo = nThLargestNo(a, -1);
		System.out.println("Highest No : " + highestNo + "\nLowest No : " + lowestNo);
	}

	// 7.==========================7.
	public static void find2ndMinMax(int[] a) {
		int secondHighest = nThLargestNo(a, 2);
		int secondLowest = nThLargestNo(a, -2);
		System.out.println("2nd Highest No : " + secondHighest + "\n2ndLowestNumber : " + secondLowest);
	}

	// 8.============================8.
	public static void commonElementsAmmongArrays(int[] a, int[] b, int[] c) {
		show(a);
		show(b);
		show(c);
		System.out.println("Common Elements are : ");
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < b.length; j++) {
				if (a[i] == b[j]) {
					for (int k = 0; k < c.length; k++) {
						if (a[i] == c[k]) {
							System.out.print(" " + a[i]);
						}
					}
				}
			}
		}
	}

	// 9.============================9.
	public static void findPairs(int[] a, int sum) {
		show(a);
		System.out.println("Pairs with sum " + sum + " are : ");
		for (int i = 0; i < a.length; i++) {
			for (int j = i + 1; j < a.length; j++) {
				if (a[i] + a[j] == sum) {
					System.out.print(" (" + a[i] + ", " + a[j] + ") , ");
				}
			}
		}
	}

	// 10.===========================10.
	public static void minPair(int[] a) {
		int[] s = removeDuplicate(sortByOrder(a));
		System.out.println("minSum : " + (a[0] + a[1]));
		System.out.println("The pair (" + a[0] + ", " + a[1] + ") will have the minimum sum pair");
	}

	// ==================================Helper Methods// Bellow============================================//

	public static void removeElement(int index) {
		for (int i = index; i < testArray.length - 1; i++) {
			testArray[i] = testArray[i + 1];
		}
		testArray[testArray.length - 1] = 0;
		int[] raw = new int[testArray.length - 1];
		for (int i = 0; i < raw.length; i++) {
			raw[i] = testArray[i];
		}
		testArray = raw;
		raw = null;
	}

	public static boolean isAvailable(int n) {
		boolean flag = false;
		for (int i = 0; i < raw.length; i++) {
			if (raw[i] == n) {
				flag = true;
			}
		}
		return flag;
	}

	public static void show(int[] x) {
		System.out.println("===========================");
		for (int i = 0; i < x.length; i++) {
			if (i == 0) {
				System.out.print(" [ " + x[i]);
			}
			System.out.print(", " + x[i]);
		}
		System.out.print(" ]");
		System.out.println("\n===========================");
	}

	public static void addElement(int m) {
		raw[rawIndex] = m;
		rawIndex++;
	}

	public static int[] sortByOrder(int[] inArrToSort) {

		int arrToSort[] = inArrToSort;
		int copy = 0;
		int iterate = 0;
		while (iterate < arrToSort.length) {
			for (int i = 0; i < arrToSort.length - 1; i++) {
				if (arrToSort[i] > arrToSort[i + 1]) {
					copy = arrToSort[i + 1];
					arrToSort[i + 1] = arrToSort[i];
					arrToSort[i] = copy;
				}
			}
			iterate++;
		}
		return arrToSort;
	}

}
